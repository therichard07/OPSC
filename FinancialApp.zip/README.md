# Budget Tracker App

This is a Kotlin Android application to track expenses, with gamification and visual feedback.