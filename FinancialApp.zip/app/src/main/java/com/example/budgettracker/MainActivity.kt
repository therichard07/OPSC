package com.example.budgettracker

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var expenseList: MutableList<Expense>
    private lateinit var adapter: ExpenseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        expenseList = mutableListOf()
        adapter = ExpenseAdapter(expenseList)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val addButton = findViewById<Button>(R.id.btnAdd)
        addButton.setOnClickListener {
            startActivity(Intent(this, AddExpenseActivity::class.java))
        }

        GamificationUtils.checkAchievements(expenseList, this)

        Log.d("MainActivity", "App launched with ${expenseList.size} expenses")
    }
}
