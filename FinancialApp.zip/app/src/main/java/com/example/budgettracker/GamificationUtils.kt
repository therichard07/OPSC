package com.example.budgettracker

import android.content.Context
import android.widget.Toast

object GamificationUtils {
    fun checkAchievements(expenses: List<Expense>, context: Context) {
        if (expenses.size >= 5) {
            Toast.makeText(context, "🎉 You’ve logged 5 expenses!", Toast.LENGTH_SHORT).show()
        }
    }
}
